# TDLib JavaScript (Node.js) example

#### Requirements

- Node.js v9.0.0+
- [Prebuilt](https://github.com/tdlib/td#building) tdjson shared library

#### Run

```console
$ npm install
$ node example.js
```
