//
// Copyright Aliaksei Levin (levlam@telegram.org), Arseny Smirnov (arseny30@gmail.com) 2014-2018
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
#pragma once

#include "td/net/TransparentProxy.h"

#include "td/utils/Status.h"

namespace td {

class HttpProxy : public TransparentProxy {
 public:
  using TransparentProxy::TransparentProxy;

 private:
  enum class State { SendConnect, WaitConnectResponse } state_ = State::SendConnect;

  void send_connect();
  Status wait_connect_response();

  Status loop_impl() override;
};

}  // namespace td
